export const environment = {
  production: true,
  basePath: `[=component.properties.apiUrl]`,
};
